(function() {
  this["null"] = this["null"] || {};
  this.PercySDKUtils.TestHelpers = (function (logger, utils) {
    'use strict';

    const process = (typeof globalThis !== "undefined" && globalThis.process) || {};
    process.env = process.env || {};
    process.env.__PERCY_BROWSERIFIED__ = true;

    globalThis.process = globalThis.process || process;

    function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

    var logger__default = /*#__PURE__*/_interopDefaultLegacy(logger);
    var utils__default = /*#__PURE__*/_interopDefaultLegacy(utils);

    const {
      assign,
      entries
    } = Object; // matches ansi escape sequences

    const ANSI_REG = new RegExp('[\\u001B\\u009B][[\\]()#;?]*((?:(?:[a-zA-Z\\d]*(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)' + '|(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-ntqry=><~]))', 'g'); // color names by ansi escape code

    const ANSI_COLORS = {
      '91m': 'red',
      '32m': 'green',
      '93m': 'yellow',
      '34m': 'blue',
      '95m': 'magenta',
      '90m': 'grey'
    }; // colorize each line of a string using an ansi escape sequence

    const LINE_REG = /^.*$/gm;

    function colorize(code, str) {
      return str.replace(LINE_REG, line => `\u001b[${code}${line}\u001b[39m`);
    } // map ansi colors to bound colorize functions


    entries(ANSI_COLORS).reduce((colors, _ref) => {
      let [code, name] = _ref;
      return assign(colors, {
        [name]: colorize.bind(null, code)
      });
    }, {});

    const ELAPSED_REG = /\s\S*?\(\d+ms\)\S*/;
    const NEWLINE_REG = /\r\n/g;
    const LASTLINE_REG = /\n$/;

    function sanitizeLog(str) {
      let {
        ansi,
        elapsed
      } = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      // normalize line endings
      str = str.replace(NEWLINE_REG, '\n'); // strip ansi colors

      if (!ansi) str = str.replace(ANSI_REG, ''); // strip elapsed time

      if (!elapsed) str = str.replace(ELAPSED_REG, ''); // strip trailing line endings

      return str.replace(LASTLINE_REG, '');
    }

    function spy(object, method, func) {
      if (object[method].restore) object[method].restore();
      let spy = Object.assign(function spy() {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }

        spy.calls.push(args);
        if (func) return func.apply(this, args);
      }, {
        restore: () => object[method] = spy.originalValue,
        reset: () => (spy.calls.length = 0) || spy,
        originalValue: object[method],
        calls: []
      });
      object[method] = spy;
      return spy;
    }

    const {
      Logger,
      loglevel
    } = logger__default["default"];
    const helpers$1 = {
      stdout: [],
      stderr: [],
      loglevel,

      async mock() {
        let options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        helpers$1.reset();

        if (process.env.__PERCY_BROWSERIFIED__) {
          spy(Logger.prototype, 'write', function (lvl, msg) {
            let stdio = lvl === 'info' ? 'stdout' : 'stderr';
            helpers$1[stdio].push(sanitizeLog(msg, options));
            return this.write.originalValue.call(this, lvl, msg);
          });
          spy(console, 'log');
          spy(console, 'warn');
          spy(console, 'error');
        } else {
          let {
            Writable
          } = await import('stream');

          for (let stdio of ['stdout', 'stderr']) {
            Logger[stdio] = Object.assign(new Writable(), {
              columns: options.isTTY ? 100 : null,
              isTTY: options.isTTY,

              cursorTo() {},

              clearLine() {},

              _write(chunk, encoding, callback) {
                helpers$1[stdio].push(sanitizeLog(chunk.toString(), options));
                callback();
              }

            });
          }
        }
      },

      reset(soft) {
        if (soft) loglevel('info');else delete Logger.instance;
        helpers$1.stdout.length = 0;
        helpers$1.stderr.length = 0;

        if (console.log.reset) {
          console.log.reset();
          console.warn.reset();
          console.error.reset();
        }
      },

      dump() {
        let msgs = Array.from(Logger.instance && Logger.instance.messages || []);
        if (!msgs.length) return;

        let log = m => process.env.__PERCY_BROWSERIFIED__ ? console.log.and ? console.log.and.originalFn(m) : console.log(m) : process.stderr.write(`${m}\n`);

        logger__default["default"].loglevel('debug');
        log(logger__default["default"].format('testing', 'warn', '--- DUMPING LOGS ---'));
        msgs.reduce((last, _ref) => {
          let {
            debug,
            level,
            message,
            timestamp
          } = _ref;
          log(logger__default["default"].format(debug, level, message, timestamp - last));
          return timestamp;
        }, msgs[0].timestamp);
      }

    };

    const helpers = {
      logger: helpers$1,

      async setup() {
        utils__default["default"].percy.version = '';
        delete utils__default["default"].percy.config;
        delete utils__default["default"].percy.enabled;
        delete utils__default["default"].percy.domScript;
        delete process.env.PERCY_SERVER_ADDRESS;
        await helpers.call('server.mock');
        await helpers$1.mock();
      },

      teardown: () => helpers.call('server.close'),
      getRequests: () => helpers.call('server.requests'),
      testReply: (path, reply) => helpers.call('server.reply', path, reply),
      testFailure: function () {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }

        return helpers.call('server.test.failure', ...args);
      },
      testError: path => helpers.call('server.test.error', path),
      testSerialize: fn => !fn ? helpers.call('server.test.serialize') // get
      : helpers.call('server.test.serialize', fn),
      // set
      mockSite: () => helpers.call('site.mock'),
      closeSite: () => helpers.call('site.close')
    };

    if (process.env.__PERCY_BROWSERIFIED__) {
      helpers.call = async function call(event) {
        for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
          args[_key2 - 1] = arguments[_key2];
        }

        let {
          socket,
          pending = {}
        } = helpers.call;

        if (!socket) {
          socket = new window.WebSocket('ws://localhost:5339');
          await new Promise((resolve, reject) => {
            let done = event => {
              clearTimeout(timeoutid);
              socket.onopen = socket.onerror = null;

              if (event && (event.error || event.type === 'error')) {
                reject(event.error || new Error('Test client connection failed'));
              } else resolve(socket);
            };

            let timeoutid = setTimeout(done, 1000, {
              error: new Error('Test client connection timed out')
            });
            socket.onopen = socket.onerror = done;
          });

          socket.onmessage = _ref => {
            let {
              data
            } = _ref;
            let {
              id,
              resolve,
              reject
            } = JSON.parse(data);
            if (!pending[id]) return;
            if (resolve) pending[id].resolve(resolve.result);
            if (reject) pending[id].reject(reject.error);
          };

          Object.assign(helpers.call, {
            socket,
            pending
          });
        }

        let id = helpers.call.uid = (helpers.call.uid || 0) + 1;
        args = args.map(a => typeof a === 'function' ? a.toString() : a);
        socket.send(JSON.stringify({
          id,
          event,
          args
        }));
        return (pending[id] = {}).promise = new Promise((resolve, reject) => {
          Object.assign(pending[id], {
            resolve,
            reject
          });
        });
      };
    } else {
      helpers.call = async function call() {
        let {
          context
        } = await import('./server.js');
        helpers.context = helpers.context || (await context());
        return helpers.context.call(...arguments);
      };
    }

    return helpers;

  })(PercySDKUtils.logger, PercySDKUtils);
}).call(window);

if (typeof define === "function" && define.amd) {
  define([], () => window.PercySDKUtils.TestHelpers);
} else if (typeof module === "object" && module.exports) {
  module.exports = window.PercySDKUtils.TestHelpers;
}
